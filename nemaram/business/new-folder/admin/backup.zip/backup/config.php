<?php
$servername = "localhost";
$username = "a1669e9b_adminweb";
$password = "G%1()&@6~dkA";
$database ="a1669e9b_adminweb";
// Create connection
$db = mysqli_connect($servername, $username, $password, $database);

// Check connection
// if (!$db) {
//   die("Connection failed: " . mysqli_connect_error());
// }
// echo "Connected successfully";
?>